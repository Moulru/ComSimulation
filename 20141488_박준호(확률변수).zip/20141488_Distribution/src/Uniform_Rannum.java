class Uniform_Num {
	int i=0, j=0;
	int a=0, b=0;
	Uniform_Num(int a, int b) {
		this.a = a;
		this.b = b;
	}
	
	public void printNum() {
		
		System.out.print("\n\t *** Uniform Continuous Distribution *** \n\n");
		float[][] unfrm = new float[10][9];
		int r;
		
		for(i=1; i<10; i++) {
			for (j=1; j<9; j++) {
				r = (int)(Math.random()*100);
				unfrm[i][j] = a+(b-a) * r;
				System.out.printf("%6.2f", unfrm[i][j]/100);
				}
			System.out.print("\n");
		}
	}
}

public class Uniform_Rannum {
	public static void main(String[] args) {
		Uniform_Num rn = new Uniform_Num(0,20);
		
		rn.printNum();
	}
}