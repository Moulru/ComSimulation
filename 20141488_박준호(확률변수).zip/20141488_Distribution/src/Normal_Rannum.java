class Normal_Num {
	int i=0, j=0;
	int std, ex;
	Normal_Num(int a, int b) {
		this.std = a;
		this.ex = b;
	}
	
		
	public void printNum() {
		int r = 0;
		double w = 0;
		double sum = 0;
		
		System.out.print("\n\t *** Normal Distribution *** \n\n");
		double[][] fnorm = new double[10][9];
				
		for(i=1; i<10; i++) {
			for (j=1; j<9; j++) {
				r = 0;
				w = 0;
				sum = 0;
				
				for (int q=0; q<=1000; q++) {
					r = (int)(Math.random()*1000);
					w = (double)r / 1000;
					sum += w;
					w = (sum - 500) / Math.sqrt(1000/12);
					}
								
				fnorm[i][j] = w;
				
				System.out.printf("%7.2f", std * fnorm[i][j]+ex);
			}
			System.out.print("\n");
		}
	}
}

public class Normal_Rannum {
	public static void main(String[] args) {
		Normal_Num nr = new Normal_Num(3,10);
		
		nr.printNum();
	}
}
