import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

class RanNumber {
	private double exnum1 = 0;
	private double exnum2 = 0;
	private double num2 = 0;
	private double hap = 0;
	
	RanNumber(double exnum1, double exnum2) {
		this.exnum1 = exnum1;
		this.exnum2 = exnum2;
	}
	
	public int random() {
		int result = 0;
		
		num2 = exnum1 * exnum2;
		hap = num2 % 100000;
		exnum2 = hap + 25;
		
		hap = hap / 1000;
		
		result = (int)hap;
		
		return result;
	}
}

public class HouseRandom {
	public static void main(String[] args) {
		RanNumber r1 = new RanNumber(1372,9463);
		
		int apt;
		int room;
		
		int exnum = 0;
		
		String[] person = {"김갑을", "김을병", "김병정", "김정무", "박무기", "박기경", "박경신", "이신임", "이임계", "조계갑",
				"김자축", "김인묘", "이진사", "김오미", "이미신", "박유술", "박술해", "김장훈", "이효리", "유재석",
				"원빈", "조정석", "이정재", "아이유", "임영웅", "이찬원", "영탁", "정동원", "김호중", "장민호"};
		
		List<String> list = new ArrayList<>(Arrays.asList(person));
		
		int per = list.size();
		
		System.out.println("@@@아파트 주택 청약 당첨 프로그램@@@");
		System.out.println("#101동 1001호부터 102동 1003호까지 총 6개의 방");
		System.out.println("#대기자는 "+ per + "명 입니다.");
		
		for(apt=101; apt<103; apt++) {
			for(room=1001; room<1004; room++) {
				System.out.print(apt + "동" + room+"호의 ");
				exnum = r1.random();
				while(exnum>=per) {
					exnum = r1.random();
				}
				
				System.out.println("당첨자는 " + list.get(exnum) + "입니다.");
				
				list.remove(exnum);
				per = list.size();
				System.out.println("#대기자는 "+ per + "명 입니다.");
			}
		}
	}
}