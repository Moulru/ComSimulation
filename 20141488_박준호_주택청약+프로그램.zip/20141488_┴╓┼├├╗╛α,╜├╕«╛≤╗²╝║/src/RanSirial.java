import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;


class RanNumberEx1 {
	private double exnum1 = 0;
	private double exnum2 = 0;
	private double num2 = 0;
	private double hap = 0;
	
	RanNumberEx1(double exnum1, double exnum2) {
		this.exnum1 = exnum1;
		this.exnum2 = exnum2;
	}
	
	public int random() {
		int result = 0;
		
		num2 = exnum1 * exnum2;
		hap = num2 % 100000;
		exnum2 = hap;
		
		hap = hap / 1000;
		
		result = (int)hap;
		
		return result;
	}
}

public class RanSirial {

	public static void main(String[] args) {
		RanNumberEx1 r1 = new RanNumberEx1(1372,9463);
		int ranNum=0;
		
		String[] eng = {"A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","W","X","Y","Z","1","2","3","4","5","6","7","8","9","0"};
		
		List<String> list = new ArrayList<>(Arrays.asList(eng));
		int abc = list.size();
		
		for(int i=0; i<10; i++) {
			System.out.print(i+1 + "번째 시리얼넘버 : ");
			
			for(int j=0; j<10; j++) {
				ranNum = r1.random();
				
				while(ranNum>=abc) {
					ranNum = r1.random();
				}
				
				System.out.print(list.get(ranNum));
			}
			
			System.out.println();
		}
	}
}
